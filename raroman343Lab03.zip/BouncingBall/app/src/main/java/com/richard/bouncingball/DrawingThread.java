package com.richard.bouncingball;
import android.os.Handler;
import android.os.Looper;
import android.view.View;

/**
 * Created by Richard and Profesor Fuchs on 4/7/2015.
 */
public class DrawingThread  {
    private View theView;
    private float framesPerSecond;
    private  Thread thread;
    private volatile boolean isRunning;
    private Handler handler;


    public DrawingThread(View v, float fps){
        theView=v;
        framesPerSecond = fps;
        isRunning = false;
        handler  = new Handler(Looper.getMainLooper());
    }
    public boolean isRunning(){
        return isRunning;
    }

    public void start(){
        if(thread == null){
            thread = new Thread(new ThreadRunner());
            thread.start();
            isRunning = true;
        }
    }
    public void stop(){

        if(thread != null){
            isRunning = false;
            try{
                thread.join();
            }catch(InterruptedException ie){

            }
            thread = null;
        }

    }

    private class ThreadRunner implements Runnable{
        @Override
        public void run(){
            while(isRunning){
                try{
                    Thread.sleep((long)(100/framesPerSecond));//frame action happens here
                    handler.post( new Updater());
                }catch (InterruptedException ie){
                    isRunning = false;
                }
            }
        }
    }
    private class Updater implements Runnable{
        @Override
        public void  run(){
            theView.invalidate();
        }
    }

}
