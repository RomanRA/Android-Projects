/*
 * Author: Richard A. Roman And Professor Fuchs
 * 4/18/2015
 * Ballview.java - this activity cretes a bal and paddle sprite to display on screen. If the two sprites
 * make contact the ball sprite changes direction. User moves the paddle sprite left to right to deflect ball sprite.
 *
 */
package com.richard.bouncingball;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import static android.graphics.RectF.intersects;

public class BallView extends View {
    public final static float BALL_SIZE = 50.0f;
    public final static float MAX_VELOCITY = 50.0f;


    private Sprite ball1;
    private Sprite paddle1;
    private DrawingThread thread;

    public BallView(Context context, AttributeSet attrs) {
        super(context, attrs);
    /*
        ball1 = new Sprite((float)(Math.random() - .5) * 2 * MAX_VELOCITY,
                (float)(Math.random() - .5) * 2 * MAX_VELOCITY,
                (float)(Math.random() - .5) * 2 * MAX_VELOCITY,
                (float)(Math.random() - .5) * 2 * MAX_VELOCITY);

                */

        // set up initial state of ball
        ball1 = new Sprite(250, 250, 15, 15);
        paddle1 = new Sprite(300,400,0,0);

        ball1.setSize(BALL_SIZE, BALL_SIZE);
        paddle1.setSize(150, 20);

        // start a drawing thread to animate screen at 50 frames/sec
        thread = new DrawingThread(this, 25);
        thread.start();
    }


    @Override
    protected void onDraw(Canvas drawingCanvas) {
        super.onDraw(drawingCanvas);


        if(intersects(paddle1.getRect(),ball1.getRect())){

            float xVel = ball1.getxVelocity();
            float yVel = ball1.getyVelocity();

            ball1.setxVelocity(xVel * -1);
            ball1.setyVelocity(yVel * -1);
        }

        drawingCanvas.drawOval(ball1.getRect(), ball1.getPaint());
        drawingCanvas.drawRect(paddle1.getRect(),paddle1.getPaint());
        updateBall();
    }

    public void updateBall() {
        ball1.updateLocation(getWidth(), getHeight());

    }

    @Override
    public boolean onTouchEvent(MotionEvent me) {

        float xPosition1 = me.getX();
        float yPosition1 = me.getY();

        if(paddle1.getRect().left > xPosition1 || paddle1.getRect().right < xPosition1){

            paddle1.setLocation(xPosition1 - 75,400);
        }



//        float xLoc = me.getX();
//        float yLoc = me.getY();

//        float xVel = ball1.getxVelocity();
//        float yVel = ball1.getyVelocity();

//        ball1.setxVelocity(xVel * -1);
//        ball1.setyVelocity(yVel * -1);

        return super.onTouchEvent(me);
    }
}