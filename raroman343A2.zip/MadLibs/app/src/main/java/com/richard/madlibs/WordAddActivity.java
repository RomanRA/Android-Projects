/*
 * Author: Richard A. Roman
 * 2/18/2015
 * WordAddActivity.java - this activity prompts the user to enter the words within the randomly selected story It displays the number of words
 * left and what type of word to enter. The user can't continue to next word without tye in something(not left blank).Once the story is completly full a
 * bundle is created and passed into intent to create the third final activity ResultActivity.java
 *
 */
package com.richard.madlibs;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.os.Build;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.io.IOException;
import java.io.InputStream;
import java.util.Random;

public class WordAddActivity extends ActionBarActivity {

    //MEMBER VARIABLES
    InputStream file = null;
    String storyFull = "";
    String placeholder1 = "";
    String placeholder = "";
    MadLibStory story;
    int numberLeft = 0;
    int num = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_word_add);

        //SETS TYPE FACE FOR ACTIVITY
        initTypeface();

        //HIDE THE TOP MENU BAR IN APP
        getSupportActionBar().hide();

        //GENERATE A RANDOM NUMBER TO CHOOSE WHAT FILE TO OPEN
        AssetManager asset = getAssets();
        Random random = new Random();
        num = random.nextInt(5);

        try{
            if(num == 0){
                file = asset.open("madlib0_simple.txt");
            }
            if(num == 1){
                file = asset.open("madlib1_tarzan.txt");
            }
            if(num == 2){
                file = asset.open("madlib2_university.txt");
            }
            if(num == 3){
                file = asset.open("madlib3_clothes.txt");
            }
            if(num == 4){
                file = asset.open("madlib4_dance.txt");
            }
        }
        catch(IOException e1){
            e1.printStackTrace();
        }
        //CREATE MADLIB STORY OBJECT
        story = new MadLibStory(file);
        checkText();


    }//end on create


    private void initTypeface() {
        Typeface dekko = Typeface.createFromAsset(getAssets(),"fonts/Dekko.ttf");

        EditText text = (EditText)findViewById(R.id.fill_in);
        text.setTypeface(dekko);

        TextView heading = (TextView)findViewById(R.id.heading);
        heading.setTypeface(dekko);

        TextView text2 = (TextView)findViewById(R.id.textView2);
        text2.setTypeface(dekko);

        TextView text3 = (TextView)findViewById(R.id.textView3);
        text3.setTypeface(dekko);

    }

    public void checkText() {

        EditText text = (EditText)findViewById(R.id.fill_in);
        TextView text2 = (TextView)findViewById(R.id.textView2);
        TextView text3 = (TextView)findViewById(R.id.textView3);

        //GETS WHICH WORD NEEDS TO GO IN SPOT
        placeholder1 = story.getNextPlaceholder();
        numberLeft = story.getPlaceholderRemainingCount();

        //UPDATE COUNT WORDS LEFT
        text2.setText(numberLeft +" word(s) left");
        placeholder = placeholder1.replaceAll("-!'","");

        //CHECK PLACEHOLDERS AND SET  HINT  AND TET TELLING USER WHAT TO ENTER
        if (placeholder.equalsIgnoreCase("job")) {
            text.setHint("Job");
            text3.setText("Please type a/an job");
        }
        if (placeholder.equalsIgnoreCase("adjective")) {
            text.setHint("Adjective");
            text3.setText("Please type a/an adjective");
        }
        if (placeholder.equalsIgnoreCase("plural noun")) {
            text.setHint("Plural Noun");
            text3.setText("Please type a/an plural noun");
        }
        if (placeholder.equalsIgnoreCase("noun")) {
            text.setHint("Noun");
            text3.setText("Please type a/an noun");
        }
        if (placeholder.equalsIgnoreCase("place")) {
            text.setHint("Place");
            text3.setText("Please type a/an place");
        }
        if (placeholder.equalsIgnoreCase("funny noise")) {
            text.setHint("Funny Noise");
            text3.setText("Please type a/an funny noise");
        }
        if (placeholder.equalsIgnoreCase("person's name")) {
            text.setHint("Person's Name");
            text3.setText("Please type a/an person's name");
        }
        if (placeholder.equalsIgnoreCase("number")) {
            text.setHint("Number");
            text3.setText("Please type a/an number");
        }
        if (placeholder.equalsIgnoreCase("job title")) {
            text.setHint("Job Title");
            text3.setText("Please type a/an job title");
        }
        if (placeholder.equalsIgnoreCase("male name")) {
            text.setHint("Male Name");
            text3.setText("Please type a/an male name");
        }
        if (placeholder.equalsIgnoreCase("city")) {
            text.setHint("City");
            text3.setText("Please type a/an city");
        }
        if (placeholder.equalsIgnoreCase("unusual adjective")) {
            text.setHint("Unusual Adjective");
            text3.setText("Please type a/an unusual adjective");
        }
        if (placeholder.equalsIgnoreCase("color!")) {
            text.setHint("Color");
            text3.setText("Please type a/an color");
        }
        if (placeholder.equalsIgnoreCase("exciting adjective")) {
            text.setHint("Exciting Adjective");
            text3.setText("Please type a/an exciting adjective");
        }
        if (placeholder.equalsIgnoreCase("interesting adjective")) {
            text.setHint("Interesting Adjective");
            text3.setText("Please type a/an interesting adjective");
        }
        if (placeholder.equalsIgnoreCase("adverb")) {
            text.setHint("Adverb");
            text3.setText("Please type a/an adverb");
        }
        if (placeholder.equalsIgnoreCase("verb")) {
            text.setHint("Verb");
            text3.setText("Please type a/an verb");
        }
        if (placeholder.equalsIgnoreCase("body part")) {
            text.setHint("Body Part");
            text3.setText("Please type a/an body part");
        }

    }//end check text method


    @TargetApi(Build.VERSION_CODES.GINGERBREAD)
    public void onClick(View view){

        //GET WHAT WAS ENTERED BY THE USER IN FIELD
        TextView text = (TextView)findViewById(R.id.fill_in);

        //ERROR CHECK FOR EMPTY FIELD
        if((text.getText().toString().equals(""))){
            //MESSAGE TO USER CANNOT BE EMPTY
            Context context2 = getApplicationContext();
            CharSequence message2 = "Field cannot be empty!";
            int duration2 = Toast.LENGTH_SHORT;
            Toast.makeText(context2,message2,duration2).show();
        }
        else{
            //MESSAGE TO USER AFTER A WORD
            Context context = getApplicationContext();
            CharSequence message = "Great! Keep going!";
            int duration = Toast.LENGTH_SHORT;
            Toast.makeText(context,message,duration).show();

            //MAKE STORY WORD ADDED BY USER BOLD
            story.fillInPlaceholder("<b>"+text.getText().toString()+"</b>");
            text.setText("");

            //cHECK IF THE STORY IS FILLED
            if(!story.isFilledIn()){
                checkText();
            }
            else if(story.isFilledIn() ) {
                Bundle tempBundle = new Bundle();

                storyFull = story.toString();
                tempBundle.putString("completeStory", storyFull);

                //SEND INTENT AND BUNDLE TO THIRD ACTIVITY RESULTACTIVITY.JAVA
                Intent intent = new Intent(view.getContext(), ResultActivity.class);
                intent.putExtras(tempBundle);
                startActivity(intent);
            }
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_word_add, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
