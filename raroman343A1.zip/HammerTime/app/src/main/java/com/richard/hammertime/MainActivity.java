/* MainActivity.java - This program calculates customers desk order price depending on what the user enters into the input fields
 * Name: Richard A Roman
 * Class: CSCI 343
 * Date: 2/2/2015
 * Assignment 1
 * Email: raroman@g.coastal.edu
 */

package com.richard.hammertime;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends ActionBarActivity {


    double basePriceNum = 0;
    String myBasePrice ="";
    double surfaceAreaEdit=0;
    String mySurfaceArea="";

    private String woodSelected ="";
    private String drawersSelected= "";

    double sumTotalForDrawers=0;
    double sumTotalForWoodType=0;
    double sumTotalForSurface=0;
    String transactionTotal="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Get instance of both spinners
        Spinner spinner1 = (Spinner)findViewById(R.id.wood_spinner);
        Spinner spinner2 = (Spinner)findViewById(R.id.draw_spinner);

        ArrayAdapter<CharSequence>dataAdapter1 = ArrayAdapter.createFromResource(this,R.array.wood_type,android.R.layout.simple_spinner_dropdown_item);
        dataAdapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner1.setAdapter(dataAdapter1);

        //create listener for first spinner
        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                //Get the type of wood the user selected
                woodSelected = parent.getItemAtPosition(pos).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        ArrayAdapter<CharSequence>dataAdapter2 = ArrayAdapter.createFromResource(this,R.array.number_of_drawers,android.R.layout.simple_spinner_dropdown_item);
        dataAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(dataAdapter2);

        //Create listener for second spinner
        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                //Get the number of drawers selected by user
                drawersSelected = parent.getItemAtPosition(pos).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }
    //Called when the user clicks the calculate button
    @TargetApi(Build.VERSION_CODES.GINGERBREAD)
    public void calculateCost(View view) {
        //Get instance
        EditText basePrice = (EditText) findViewById(R.id.base_Price);
        //Get string
        myBasePrice = basePrice.getText().toString();
        if(myBasePrice != null && !myBasePrice.isEmpty()){
            //parse to double
            basePriceNum = Double.parseDouble(myBasePrice);

        }
        else{
            basePriceNum=200;
        }

        //Get instance
        EditText surfaceArea = (EditText) findViewById(R.id.surface_area);
        //Get String
        mySurfaceArea = surfaceArea.getText().toString();
        //Check to see if user didnt leave surface area empty
        if(mySurfaceArea !=null && !mySurfaceArea.isEmpty()){
            surfaceAreaEdit = Double.parseDouble(mySurfaceArea);


            //Check wood selection
            if(woodSelected.equalsIgnoreCase("mahogany")){
                sumTotalForWoodType = 150;
            }
            else if(woodSelected.equalsIgnoreCase("oak")){
                sumTotalForWoodType = 125;
            }
            else if(woodSelected.equalsIgnoreCase("Pine")){
                sumTotalForWoodType = 0;
            }

            //Check number of drawers
            int index;
            int sum = 0;
            int drawers = Integer.parseInt(drawersSelected);
            for(index=0; index<drawers; index++){
                sum = sum + 30;
            }
            //Sum total for the number of drawers
            sumTotalForDrawers = sum;

            //Calculate surface area
            if(surfaceAreaEdit>750 && surfaceAreaEdit<1000){
                sumTotalForSurface = 100;
            }
            else if(surfaceAreaEdit>= 1000){
                sumTotalForSurface = 250;
            }

            //check base price
            if(basePriceNum!=0){
                //Next add up total cost
                transactionTotal = "$" + Double.toString(basePriceNum + sumTotalForWoodType + sumTotalForDrawers + sumTotalForSurface);
            }
            else{
                basePriceNum = 200;
                transactionTotal = "$" + Double.toString(basePriceNum + sumTotalForWoodType + sumTotalForDrawers + sumTotalForSurface);
            }

            //Send back to display to user
            TextView cost = (TextView)findViewById(R.id.editTextCost);
            cost.setText(transactionTotal);

            //Display message to user that the ost was calculated
            Context context = getApplicationContext();
            CharSequence text = "Cost Calculated";
            int duration = Toast.LENGTH_LONG;

            Toast.makeText(context,text,duration).show();
        }//End if
        else{
            //Display message to user error
            Context context = getApplicationContext();
            CharSequence text = "Surface Area Cannot Be Empty!";
            int duration = Toast.LENGTH_LONG;

            Toast.makeText(context,text,duration).show();
        }//End else
    }//End calculate cost method


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

}//End Main activity class
