package com.richard.todolist;


import android.content.Context;
import android.graphics.Typeface;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;


public class MainActivity extends ActionBarActivity{

    //Declare private variables
    private  ArrayList<String> toDoArray = new ArrayList<String>();
    private ArrayAdapter<String> myAdapter ;
    private ListView listViewToDo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        initTypeface();

        listViewToDo = (ListView) findViewById(R.id.listViewToDo);
        myAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_expandable_list_item_1, toDoArray);
        listViewToDo.setAdapter(myAdapter);

        listViewListener();
    }
    private void initTypeface() {
        Typeface ArchD = Typeface.createFromAsset(getAssets(),"fonts/ArchD.ttf");
        TextView textView = (TextView)findViewById(R.id.textView);
        textView.setTypeface(ArchD);
        TextView textView2 = (TextView)findViewById(R.id.textView2);
        textView2.setTypeface(ArchD);
        EditText editText = (EditText)findViewById(R.id.entered_data);
        editText.setTypeface(ArchD);
        Button add_Button = (Button)findViewById(R.id.add_button);
        add_Button.setTypeface(ArchD);
    }

    public void onClick(View view){
        EditText dataEntered = (EditText)findViewById(R.id.entered_data);
        String theThingToDo = dataEntered.getText().toString();

        myAdapter.add(theThingToDo);
        dataEntered.setText("");
    }
    public void listViewListener(){
        listViewToDo.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener(){
            @Override
            public boolean onItemLongClick(AdapterView<?> adapter, View item, int pos, long id){
                toDoArray.remove(pos);
                myAdapter.notifyDataSetChanged();
                //write();
                return true;
            }

        });
    }
    @Override
    protected void onResume(){
        super.onResume();
        try{
            Scanner scan = new Scanner(openFileInput("todolist.txt"));
            while(scan.hasNext()){
                toDoArray.add(scan.nextLine());
            }
            scan.close();
            myAdapter.notifyDataSetChanged();
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
    @Override
    protected void onPause(){
        super.onPause();
        try {
            PrintStream out = new PrintStream (openFileOutput("todolist.txt", Context.MODE_PRIVATE));
            for(int index = 0;index<toDoArray.size();index++){
                out.println(toDoArray.get(index));
            }
            out.close();
            toDoArray.clear();
            myAdapter.notifyDataSetChanged();
        }
        catch(IOException e){
            e.printStackTrace();
        }
  }


//    @Override
//    public void onSaveInstanceState(Bundle savedInstanceState){
//        super.onSaveInstanceState(savedInstanceState);
//        savedInstanceState.putStringArrayList("array", toDoArray);
//    }
//    @Override
//    public void onRestoreInstanceState(@NonNull Bundle savedInstanceState){
//        super.onRestoreInstanceState(savedInstanceState);
//        toDoArray = savedInstanceState.getStringArrayList("array");
//    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


}
