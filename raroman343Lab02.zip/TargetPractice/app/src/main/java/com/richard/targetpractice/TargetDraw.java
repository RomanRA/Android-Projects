/*
 *Richard A. Roman
 * TargetDraw.java- draws a target on to screen using on draw method
 * 4/3/2015
 */
package com.richard.targetpractice;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;


public class TargetDraw extends View {

    public TargetDraw(Context context, AttributeSet attrs){
        super(context,attrs);
    }

    @Override
    protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        Paint paint = new Paint();

        paint.setColor(Color.RED);
        canvas.drawCircle((float)getWidth()/2,(float)getHeight()/2,150.0f,paint);

        paint.setColor(Color.WHITE);
        canvas.drawCircle((float)getWidth()/2,(float)getHeight()/2,120.0f,paint);

        paint.setColor(Color.RED);
        canvas.drawCircle((float)getWidth()/2,(float)getHeight()/2,90.0f,paint);

        paint.setColor(Color.WHITE);
        canvas.drawCircle((float) getWidth() / 2, (float) getHeight() / 2, 60.0f, paint);

        paint.setColor(Color.RED);
        canvas.drawCircle((float)getWidth()/2,(float)getHeight()/2,30.0f,paint);











    }
}
