/*
 * Author: Richard A. Roman
 * 4/2/2015
 * MovieFragment.java- Movie information data is displayed in this fragment. User clicks button to laod the nextmovie within object.
 *
 */
package com.richard.fourtodo;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.HashMap;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link MovieFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link MovieFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class MovieFragment extends Fragment implements View.OnClickListener{
    //Member Variables
    HashMap data;
    int count = 0;
    int size = 0;
    MovieData movieData;
    String description;
    String length;
    String year;
    String director;
    String rating;
    String stars;
    String url;


    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment MovieFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static MovieFragment newInstance(String param1, String param2) {
        MovieFragment fragment = new MovieFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    public MovieFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        //return inflater.inflate(R.layout.fragment_movie, container, false);
        View view = inflater.inflate(R.layout.fragment_movie,container,false);
        Button button = (Button)view.findViewById(R.id.button);
        button.setOnClickListener(this);
        return view;
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mListener = (OnFragmentInteractionListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        public void onFragmentInteraction(Uri uri);
    }
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        movieData = new MovieData();
        data = movieData.getItem(count);
        int image;

        ImageView image1 = (ImageView)getView().findViewById(R.id.image);
        TextView text1 = (TextView)getView().findViewById(R.id.textView5);
        TextView text2 = (TextView)getView().findViewById(R.id.textView6);
        TextView text3 = (TextView)getView().findViewById(R.id.textView7);
        TextView text4 = (TextView)getView().findViewById(R.id.textView8);
        TextView text5 = (TextView)getView().findViewById(R.id.textView9);
        TextView text6 = (TextView)getView().findViewById(R.id.textView10);
        TextView text7 = (TextView)getView().findViewById(R.id.textView11);

        description = data.remove("description").toString();
        length = data.remove("length").toString();
        year = data.remove("year").toString();
        director = data.remove("director").toString();
        rating = data.remove("rating").toString();
        stars = data.remove("stars").toString();
        url = data.remove("url").toString();
        image = Integer.parseInt(data.remove("image").toString());

        text1.setText(description);
        text2.setText("Time: " + length);
        text3.setText("Year: "+ year);
        text4.setText("Director: "+ director);
        text5.setText("Rating: "+rating+ "/10");
        text6.setText("Actors: "+ stars);
        text7.setText("Website: "+url);
        image1.setImageResource(image);
    }

    @Override
    public void onClick(View view){
        
        count++;

        movieData = new MovieData();
        data = movieData.getItem(count);
        size = movieData.getSize();
        int image;

        if(count < size) {
            ImageView image1 = (ImageView) getView().findViewById(R.id.image);
            TextView text1 = (TextView) getView().findViewById(R.id.textView5);
            TextView text2 = (TextView) getView().findViewById(R.id.textView6);
            TextView text3 = (TextView) getView().findViewById(R.id.textView7);
            TextView text4 = (TextView) getView().findViewById(R.id.textView8);
            TextView text5 = (TextView) getView().findViewById(R.id.textView9);
            TextView text6 = (TextView) getView().findViewById(R.id.textView10);
            TextView text7 = (TextView) getView().findViewById(R.id.textView11);

            description = data.remove("description").toString();
            length = data.remove("length").toString();
            year = data.remove("year").toString();
            director = data.remove("director").toString();
            rating = data.remove("rating").toString();
            stars = data.remove("stars").toString();
            url = data.remove("url").toString();
            image = Integer.parseInt(data.remove("image").toString());

            text1.setText(description);
            text2.setText("Time: " + length);
            text3.setText("Year: "+ year);
            text4.setText("Director: "+ director);
            text5.setText("Rating: "+rating+ "/10");
            text6.setText("Actors: "+ stars);
            text7.setText("Website: "+url);
            image1.setImageResource(image);
        }
        else{
            count = -1;

        }
    }

}
