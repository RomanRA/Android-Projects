/*
 * Author: Richard A. Roman
 * 4/2/2015
 * SeekFragment.java - a fragment that has a seekbar and imageview. The seek bar mark is  initially palced in middle.
 * Allows the user too resize image on screen with seekbar.
 *
 */

package com.richard.fourtodo;

import android.app.Activity;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link SeekFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link SeekFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class SeekFragment extends Fragment implements SeekBar.OnSeekBarChangeListener, View.OnLongClickListener {

    //Variable
    ImageView theImage;
    int progress = 0;
    SeekBar seekbar;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment SeekFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static SeekFragment newInstance(String param1, String param2) {
        SeekFragment fragment = new SeekFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    public SeekFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_seek, container, false);
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mListener = (OnFragmentInteractionListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }



    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        public void onFragmentInteraction(Uri uri);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        theImage = (ImageView)getView().findViewById(R.id.imageSeek);
        Drawable mDrawable = getResources().getDrawable(R.drawable.forrest_gump);
        theImage.setImageDrawable(mDrawable);
        theImage.setOnLongClickListener(this);

        seekbar = (SeekBar)getView().findViewById(R.id.seekBar);

        seekbar.setOnSeekBarChangeListener(this);
        seekbar.setProgress(50);

    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int progressValue, boolean fromUser) {
        progress = progressValue;
        theImage.setScaleType(ImageView.ScaleType.FIT_CENTER);

        theImage.setMinimumWidth(progress * 6);
        theImage.setMinimumHeight(progress * 6);

        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(progress * 6,progress * 6);
        params.setMargins(100,75,100,75);
        theImage.setLayoutParams(params);

    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {Toast.makeText(getView().getContext(),"On Tracking",Toast.LENGTH_LONG).show();
    }
    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {Toast.makeText(getView().getContext(),"Stop Tracking",Toast.LENGTH_LONG).show();}

    @Override
    public boolean onLongClick(View v) {
        seekbar.setProgress(50);
        return true;
    }

}
