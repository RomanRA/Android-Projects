/*
 * Author: Richard A. Roman
 * 4/2/2015
 * MainActivity.java - contains Action Bar. Each element corresponds to the another task which is contained in it
 * corresponding fragment which is loading into MainActivity.java whenever its pressed
 *
 */

package com.richard.fourtodo;

import android.net.Uri;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;


public class MainActivity extends ActionBarActivity implements Task2Fragment.OnFragmentInteractionListener, MovieFragment.OnFragmentInteractionListener,SeekFragment.OnFragmentInteractionListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        if (id == R.id.action_settings) {
            return true;
        }
        if(id == R.id.about_me){
            //Toast.makeText(this, "Swapping Fragments!", Toast.LENGTH_LONG).show();

            //Create new frag and transaction
            Task2Fragment fragment = new Task2Fragment();
            android.support.v4.app.FragmentManager manager = getSupportFragmentManager();
            android.support.v4.app.FragmentTransaction transaction= manager.beginTransaction();
            //Replace whatever is in container with this fragment and add back to stack
            transaction.replace(R.id.main_layout, fragment);
            transaction.addToBackStack(null);
            //commit the transaction
            transaction.commit();
        }
        if(id == R.id.movie_data){
            //Create new frag and transaction
            MovieFragment movieFragment = new MovieFragment();
            android.support.v4.app.FragmentManager manager = getSupportFragmentManager();
            android.support.v4.app.FragmentTransaction transaction = manager.beginTransaction();

            transaction.replace(R.id.main_layout,movieFragment);
            transaction.addToBackStack(null);
            transaction.commit();
        }
        if(id == R.id.seek){
            SeekFragment seekFrag = new SeekFragment();
            android.support.v4.app.FragmentManager manager = getSupportFragmentManager();
            android.support.v4.app.FragmentTransaction transaction = manager.beginTransaction();

            transaction.replace(R.id.main_layout,seekFrag);
            transaction.addToBackStack(null);
            transaction.commit();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }


    @Override
    public void onFragmentInteraction(Uri uri) {

    }


}
